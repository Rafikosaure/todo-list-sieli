# Backend API

Ce repo contient le code backend

## Lancement du backend

Après avoir récupéré le REPO executez la commande npm i pour installer les dépendances du projet

Une fois les dépendances installées lancez le projet avec la commande `npm start`

```
Lien pour voir la
[documentation Swagger](http://localhost:5678/api-docs/)

Pour lire la documentation, utiliser Chrome ou Firefox
